#include "ErrorFinderManager.cpp"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
using namespace std;
int main(int argc,char *argv[])
{
ErrorFinderManager manager;
manager.performConsolidation(argc,argv);
return 0;
}
